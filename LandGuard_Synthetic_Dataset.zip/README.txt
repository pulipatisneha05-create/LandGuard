================================================================================
LANDGUARD: SYNTHETIC DATASET PACKAGE
AI-Powered Land Record Validation, Spatial GIS & Fraud Risk Scoring System
================================================================================

1. DEMONSTRATION & SYNTHETIC DATA DISCLAIMER
--------------------------------------------------------------------------------
All datasets, names, survey numbers, boundary coordinates, and legal documents
in this package are 100% SYNTHETIC AND FICTIONAL.
They were generated programmatically for prototyping, algorithm verification,
and machine learning / NLP benchmarking in the LandGuard project.
No real individuals, real landowners, real government titles, or real-world
land parcels are represented in these records.

--------------------------------------------------------------------------------
2. PACKAGE CONTENTS & FOLDER STRUCTURE
--------------------------------------------------------------------------------
This archive preserves the LandGuard project folder hierarchy:

README.txt                                (This documentation file)

sample_data/
    land_records.csv                      (22 baseline land records)
    ownership_history.csv                 (22 baseline title transfer records)
    parcels.geojson                       (22 baseline Cadastral GIS polygons)
    synthetic_land_records_100.csv        (100 synthetic benchmark land records)
    synthetic_ownership_history_100.csv   (198 synthetic historical title transfers)
    parcels_synthetic_100.geojson         (103 synthetic Cadastral GIS boundary polygons)
    LandGuard_Synthetic_Test_Land_Record.pdf (Digital test PDF deed - Arun Kumar)
    ocr_test_synthetic_deed.png           (Scanned test deed PNG - Kalyan Varma)
    ocr_test_synthetic_deed.jpg           (Scanned test deed JPEG - Kalyan Varma)
    sample_deed.png                       (Synthetic test deed scan)
    test_synth_deed.png                   (Synthetic test deed scan)
    README.md                             (Sample data markdown documentation)

database/
    schema.sql                            (PostgreSQL DDL table schemas & indexes)
    seed_data.sql                         (SQL seed script for 22 baseline records)
    seed_synthetic_100.sql                (SQL seed script for 100 synthetic records)
    generate_synthetic_data.py            (Python generator script for synthetic data)
    load_synthetic_data.py                (Python loader utility for PostgreSQL)
    README.md                             (Database architecture & setup guide)

--------------------------------------------------------------------------------
3. DETAILED FILE DESCRIPTIONS & LANDGUARD APPLICATION USAGE
--------------------------------------------------------------------------------

A. TABULAR REGISTRY DATASETS (sample_data/)
-------------------------------------------
1. sample_data/land_records.csv
   - Format: Comma-Separated Values (CSV, UTF-8)
   - Size: 22 records
   - Fields: record_id, owner_name, survey_number, land_area_acres, village,
             mandal, district, state, registration_number, registration_date,
             document_type
   - LandGuard Usage: Serves as the primary reference database layer against which
     uploaded deed attributes (owner, survey number, land extent) are cross-checked.

2. sample_data/ownership_history.csv
   - Format: Comma-Separated Values (CSV, UTF-8)
   - Size: 22 records
   - Fields: history_id, survey_number, owner_name, transfer_date, transfer_type
   - LandGuard Usage: Cross-checked by Check 7 of the verification engine to
     validate historical title chains, ensure executant presence in the chain,
     and flag rapid title flipping (< 180 days).

3. sample_data/synthetic_land_records_100.csv
   - Format: Comma-Separated Values (CSV, UTF-8)
   - Size: 100 records (SYN-REC-001 to SYN-REC-100)
   - LandGuard Usage: Comprehensive benchmark dataset used by
     backend/tests/test_synthetic_dataset.py. It contains:
     * 70 Normal / Clean Title Records (SYN-REC-001 to SYN-REC-070)
     * 10 Duplicate Registration / Double Selling Cases (SYN-REC-071 to SYN-REC-080)
     * 5 Owner Name Mismatches / Impostor Sellers (SYN-REC-081 to SYN-REC-085)
     * 4 Land Area Inflations / Discrepancies (SYN-REC-086 to SYN-REC-089)
     * 3 Cadastral Survey Mismatches / Unindexed (SYN-REC-090 to SYN-REC-092)
     * 3 Rapid Successive Transfers / Flipping (SYN-REC-093 to SYN-REC-095)
     * 3 Incomplete Document Records (SYN-REC-096 to SYN-REC-098)
     * 2 Broken Title Chains (SYN-REC-099 to SYN-REC-100)

4. sample_data/synthetic_ownership_history_100.csv
   - Format: Comma-Separated Values (CSV, UTF-8)
   - Size: 198 records (SYN-HIST-001 to SYN-HIST-198)
   - LandGuard Usage: Historical transaction logs paired with the 100 synthetic
     land records, covering original grants, sales, gifts, mutations, and resales.

B. SPATIAL & GIS DATASETS (sample_data/)
----------------------------------------
5. sample_data/parcels.geojson
   - Format: GeoJSON (RFC 7946, EPSG:4326 WGS84)
   - Size: 22 parcel polygons
   - Properties: survey_number, owner, area_acres, village, mandal, district,
                 risk_level, detected_issue
   - LandGuard Usage: Baseline GIS layer rendered on the interactive Leaflet map.

6. sample_data/parcels_synthetic_100.geojson
   - Format: GeoJSON (RFC 7946, EPSG:4326 WGS84)
   - Size: 103 parcel polygons
   - Properties: survey_number, owner, area_acres, village, mandal, district,
                 risk_level (LOW, MEDIUM, HIGH, CRITICAL, DISPUTED),
                 mismatch_reason, registration_number
   - LandGuard Usage: Full synthetic GIS layer used by the GIS Map & Spatial
     Boundaries page and backend/app/gis/spatial_engine.py for spatial location
     cross-checks against village/mandal coordinates.

C. SYNTHETIC DOCUMENT FIXTURES (sample_data/)
---------------------------------------------
7. sample_data/LandGuard_Synthetic_Test_Land_Record.pdf
   - Format: Digital PDF document (2 pages)
   - Fictional Attributes: Owner: Arun Kumar, Survey: SY-TEST-104/2,
     Area: 240 square yards (0.0496 Acres), Locality: Green Valley,
     District: Demo District, Registration: DOC-TEST-2026-001, Date: 15-Sep-2026
   - LandGuard Usage: Used to verify end-to-end PDF upload, digital text stream
     extraction, and mathematical unit normalization (240 sq yds -> 0.0496 Acres).

8. sample_data/ocr_test_synthetic_deed.png & .jpg
   - Format: PNG / JPEG high-resolution scanned document images
   - Fictional Attributes: Executant: Kalyan Varma Dantuluri, Survey: SYN-101/A,
     Area: 2.20 Acres, Village: Narsingi, Mandal: Gandipet, District: Ranga Reddy
   - LandGuard Usage: Used to test computer vision preprocessing (OpenCV deskew,
     orientation detection, contrast enhancement) and Tesseract OCR extraction.

9. sample_data/sample_deed.png & test_synth_deed.png
   - Format: PNG scanned images
   - LandGuard Usage: Test fixtures for image-based deed upload and OCR confidence.

D. DATABASE SCHEMAS & SCRIPTS (database/)
-----------------------------------------
10. database/schema.sql
    - Format: PostgreSQL DDL Script
    - Tables: land_records, ownership_history, document_records,
              verification_results, risk_assessments
    - LandGuard Usage: Creates relational database tables, primary keys,
      foreign key relations, and B-tree indexes.

11. database/seed_data.sql
    - Format: SQL INSERT Statements
    - LandGuard Usage: Populates the PostgreSQL database with the 22 baseline
      records and ownership histories.

12. database/seed_synthetic_100.sql
    - Format: SQL INSERT Statements
    - LandGuard Usage: Populates the PostgreSQL database with the 100 synthetic
      records and 198 ownership histories.

13. database/generate_synthetic_data.py
    - Format: Python 3 script
    - LandGuard Usage: Standalone generator script that creates all 100 synthetic
      records, 198 ownership transfers, and 103 GeoJSON polygons deterministically.

14. database/load_synthetic_data.py
    - Format: Python 3 script
    - LandGuard Usage: Automation script to execute database/seed_synthetic_100.sql
      against a running PostgreSQL instance.

--------------------------------------------------------------------------------
4. HOW TO USE & REPRODUCE
--------------------------------------------------------------------------------
- Inspecting Data:
  * CSV files can be viewed with Microsoft Excel, LibreOffice Calc, or Python pandas.
  * GeoJSON files can be loaded into QGIS, geojson.io, or Mapshaper.
  * PDF/image files can be opened with any standard PDF viewer or image tool.

- Setting up Database:
  * In PostgreSQL:
    psql -U postgres -c 'CREATE DATABASE landguard_db;'
    psql -U postgres -d landguard_db -f database/schema.sql
    psql -U postgres -d landguard_db -f database/seed_synthetic_100.sql

- Running Generator:
  * python database/generate_synthetic_data.py

--------------------------------------------------------------------------------
5. SECURITY & SECRETS EXCLUSION VERIFICATION
--------------------------------------------------------------------------------
This dataset package has been strictly sanitized:
[X] Excludes all environment variable files (.env, .env.local, .env.production)
[X] Excludes real-world personal data, PII, or confidential government documents
[X] Excludes passwords, API keys, tokens, and database credentials
[X] Excludes full application source code, node_modules, and git history
================================================================================